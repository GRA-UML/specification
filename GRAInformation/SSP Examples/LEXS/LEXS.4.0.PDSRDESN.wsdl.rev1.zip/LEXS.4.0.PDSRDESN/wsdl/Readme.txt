LEXS 4.0 WSDL's

LEXS Publish Discover
ulexPDwebserviceImpl.wsdl (main)
ulexPDwebserviceIntf.wsdl (LEXS PD interface WSDL)

LEXS Search Retrieve
ulexSRwebserviceImpl.wsdl (main)
ulexSRwebserviceIntf.wsdl (LEXS SR interface WSDL)

LEXS Subscribe Notify
ulexSNNCwebserviceImpl.wsdl (Notification Consumer, main)
ulexSNNPwebserviceImpl.wsdl (Notification Producer, main) 
ulexSNSMwebserviceImpl.wsdl (Subscription Manager, main)
bw-2.wsdl (LEXS SN interface WSDL based on WS-BaseNotification 1.3 OASIS Standard)