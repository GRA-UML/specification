package clientBridge;

import gov.pmix.IOperator;

import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import types.*;

public class ClientBridge
{
	
	public ResponseType ProvidePrescriptionDrugHistory(RequestType request, MetaDataType metaData, Holder<ResponseStatusType> responseStatus, Holder<RoutingDataType> routingData, String address) throws Exception
	{
		PMPServiceReference service = null;
		IOperator ioperator = null;
		ResponseType response = null;
		
		try
		{
			service = new PMPServiceReference();
			ioperator = service.getWsBasicProfile();
			response = new ResponseType();
			setEndpointAddress(ioperator, address);
			
			response = ioperator.providePrescriptionDrugHistory(request, metaData, responseStatus, routingData);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			service = null;
			ioperator = null;
		}
		return response;
	}

	
	public AcknowledgementType ReceiveDeferredPrescriptionDrugHistory(ResponseType response, ResponseStatusType responseStatus, RoutingDataType routingData, Holder<Boolean> acknowledgement, String address) throws Exception
	{
		AcknowledgementType acknowledgementResponse = null;
		PMPServiceReference serviceReference;
		IOperator ioperator;

		try
		{
			acknowledgementResponse = new AcknowledgementType();
			serviceReference = new PMPServiceReference();
			ioperator = serviceReference.getWsBasicProfile();
			setEndpointAddress(ioperator, address);
			
			acknowledgementResponse = ioperator.receiveDeferredPrescriptionDrugHistory(response, responseStatus, routingData, acknowledgement);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			acknowledgementResponse = null;
			serviceReference = null;
		}
		return acknowledgementResponse;
	}

	
	private static void setEndpointAddress(Object port, String newAddress) throws Exception
	{
		BindingProvider bp;
		Map<String, Object> context;

		try
		{
			bp = (BindingProvider) port;
			context = bp.getRequestContext();
			context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, newAddress);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			bp = null;
			context = null;
		}
	}
}
