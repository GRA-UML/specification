package SOAPHandler;

import java.util.ArrayList;
import java.util.Set;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class AddressInjectHandler implements SOAPHandler<SOAPMessageContext>
{
	@Override
	public boolean handleMessage(SOAPMessageContext context)
	{
		Boolean isRequest = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
		String url = null;
		SOAPMessage soapMsg = null;
		SOAPEnvelope soapEnv = null;
		SOAPHeader soapHeader = null;
		NodeList headerNodes = null;
		NodeList nl = null;
		
		try
		{
			if (isRequest)
			{
				url = new String();

				soapMsg = context.getMessage();
				soapEnv = soapMsg.getSOAPPart().getEnvelope();
				soapHeader = soapEnv.getHeader();

				if (soapHeader == null)
				{
					soapHeader = soapEnv.addHeader();
				}

				headerNodes = soapHeader.getChildNodes();

				for (int i = 0; i < headerNodes.getLength(); i++)
				{
					if ((headerNodes.item(i).getLocalName() == "Action") && (headerNodes.item(i).getTextContent().contains("ProvidePrescriptionDrugHistory")))
					{
						url = getProvidePrescriptionDrugHistoryURL(headerNodes);
						break;
					}
					else if ((headerNodes.item(i).getLocalName() == "Action") && (headerNodes.item(i).getTextContent().contains("ReceiveDeferredPrescriptionDrugHistory")))
					{
						url = getReceiveDeferredPrescriptionDrugHistoryURL(headerNodes);
						break;
					}
				}

				nl = soapHeader.getElementsByTagName("To");
				nl.item(0).setTextContent(url);

				soapMsg.saveChanges();
				soapMsg.writeTo(System.out);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			url = null;
			soapMsg = null;
			soapEnv = null;
			soapHeader = null;
			headerNodes = null;
			nl = null;
		}
		return true;
	}


	@Override
	public boolean handleFault(SOAPMessageContext context)
	{
		return true;
	}

	
	@Override
	public void close(MessageContext context)
	{

	}

	
	@Override
	public Set<QName> getHeaders()
	{
		return null;
	}
	
	
	private String getProvidePrescriptionDrugHistoryURL(NodeList headerNodes) throws Exception
	{
		ArrayList<String> elements = null;
		String URLString = null;
		String url = null;

		try
		{
			elements = new ArrayList<String>();

			elements.add("MetaData");
			elements.add("RoutingData");
			elements.add("DisclosingState");

			URLString = returnHeaderElementValue(headerNodes, elements, 0);

			url = "urn://" + URLString.toLowerCase() + "/";
			
			System.out.println(url);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			elements = null;
			URLString = null;
		}
		return url;

	}

	
	private String getReceiveDeferredPrescriptionDrugHistoryURL(NodeList headerNodes) throws Exception
	{
		ArrayList<String> elements = null;
		String URLString = null;
		String url = null;

		try
		{
			elements = new ArrayList<String>();

			elements.add("RoutingData");
			elements.add("DisclosingState");

			URLString = returnHeaderElementValue(headerNodes, elements, 0);

			url = "urn://" + URLString.toLowerCase() + "/";
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			elements = null;
			URLString = null;
		}
		return url;
	}

	
	private String returnHeaderElementValue(NodeList nodeList, ArrayList<String> elements, int pointer)
	{
		String elementValue = null;
		Node data = null;
		String elementKey = null;
		String localName = null;
		try
		{
			elementKey = elements.get(pointer);
			for (int i = 0; i < nodeList.getLength(); i++)
			{
				localName = nodeList.item(i).getLocalName();
				if (localName.equalsIgnoreCase(elementKey))
				{
					data = nodeList.item(i);
					break;
				}
			}

			pointer++;
			if (pointer < elements.size())
			{
				elementValue = returnHeaderElementValue(data.getChildNodes(), elements, pointer);
			}
			else
			{
				elementValue = data.getTextContent();
			}
		}
		catch (NullPointerException e)
		{
			throw e;
		}
		finally
		{
			data = null;
			elementKey = null;
		}
		return elementValue;
	}
}
