package gov.pmix;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.BindingType;
import javax.xml.ws.Holder;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;
import javax.xml.ws.soap.Addressing;


import types.*;
import utilities.*;

@WebService(serviceName = "pmp", targetNamespace = "http://www.pmix.gov", portName = "WsBasicProfile")
@BindingType(value = "http://java.sun.com/xml/ns/jaxws/2003/05/soap/bindings/HTTP/")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@XmlSeeAlso({ gov.pmix.ObjectFactory.class,
		com.microsoft.schemas._2003._10.serialization.ObjectFactory.class })
@Addressing(enabled = true)
public class Operator implements IOperator
{
	@WebMethod(operationName = "ProvidePrescriptionDrugHistory", action = "http://www.pmix.gov/pmp/ProvidePrescriptionDrugHistory")
	@WebResult(name = "ResponseType", targetNamespace = "http://www.pmix.gov", partName = "parameters")
	@RequestWrapper(localName = "requestData", targetNamespace = "http://www.pmix.gov", className = "types.RequestType")
    @ResponseWrapper(localName = "responseData", targetNamespace = "http://www.pmix.gov", className = "types.ResponseType")
	public ResponseType providePrescriptionDrugHistory(
			@WebParam(name = "RequestType", targetNamespace = "http://www.pmix.gov", partName = "parameters") RequestType parameters,
			@WebParam(name = "MetaData", targetNamespace = "http://www.pmix.gov", header = true, partName = "MetaData") MetaDataType metaData,
			@WebParam(name = "ResponseStatus", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "ResponseStatus") Holder<ResponseStatusType> responseStatus,
			@WebParam(name = "RoutingData", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "RoutingData") Holder<RoutingDataType> routingData)
	{
		ResponseType ReturnValue = new ResponseType();
		String messageID = "";
		String requestingState = "";
		String responseText = null;
		try
		{
			requestingState = Helper.ReturnRequestingState(metaData);
			messageID = Helper.ReturnMessageID(metaData);

			com.microsoft.schemas._2003._10.serialization.ObjectFactory fact = new com.microsoft.schemas._2003._10.serialization.ObjectFactory();
			
			responseText =  "Request ID: " + metaData.getRoutingData().getRequestID() + "\n" +
							"Requesting State: " + metaData.getRoutingData().getRequestingState() + "\n" +
							"Disclosing State: " + metaData.getRoutingData().getDisclosingState() + "\n" +
							"Requestor: " + metaData.getRequestor() + "\n" +
							"Requestor Role: " + metaData.getRequestorRole() + "\n" +
							"Request Data: " + parameters.getRequestData() + "\n";
			
			ReturnValue.setResponseData(responseText);
			
			// Insert processing code here:

            // 1. Validate Request

            // 2. Conduct database search 

            // 3. Format response data

            // 4. Set the ResponseStatus type (NotFound, Deferred, Provided)

			responseStatus.value = ResponseStatusType.NOT_FOUND;

			// 5. If "Provided", then include the Response Data

            // 6. If "Deferred", then queue the request for additional processing
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 
		finally
		{
			messageID = null;
			requestingState = null;
		}
		return ReturnValue;
	}

	@WebMethod(operationName = "ReceiveDeferredPrescriptionDrugHistory", action = "http://www.pmix.gov/pmp/ReceiveDeferredPrescriptionDrugHistory")
	@WebResult(name = "AcknowledgementType", targetNamespace = "http://www.pmix.gov", partName = "parameters")
	public AcknowledgementType receiveDeferredPrescriptionDrugHistory(
			@WebParam(name = "ResponseType", targetNamespace = "http://www.pmix.gov", partName = "parameters") ResponseType parameters,
			@WebParam(name = "ResponseStatus", targetNamespace = "http://www.pmix.gov", header = true, partName = "ResponseStatus") ResponseStatusType responseStatus,
			@WebParam(name = "RoutingData", targetNamespace = "http://www.pmix.gov", header = true, partName = "RoutingData") RoutingDataType routingData,
			@WebParam(name = "Acknowledgement", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "Acknowledgement") Holder<Boolean> acknowledgement)
	{
		AcknowledgementType ReturnValue = new AcknowledgementType();

		String messageID = "";
		String stateID = "";

		try
		{
			stateID = Helper.ReturnRequestingState(routingData);
			messageID = Helper.ReturnRelatesTo(routingData);

			// Insert processing code here.

            // 1. Verify response data format

            // 2. If response ok, then send Acknowledgement == true
			
			acknowledgement.value = true; // temporary return value
			
			 // 3. If response NOT ok, then send Acknowledgement == false

            // 4. Process response data

            // 5. If response status == not found, then ...

            // 6. If response status == provided, then ...
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 
		finally
		{
			messageID = null;
			stateID = null;
		}
		return (ReturnValue);
	}

}
