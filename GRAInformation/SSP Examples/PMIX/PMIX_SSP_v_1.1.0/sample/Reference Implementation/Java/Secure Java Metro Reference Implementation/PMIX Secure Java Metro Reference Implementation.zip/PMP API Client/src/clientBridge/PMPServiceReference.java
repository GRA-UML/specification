package clientBridge;

import gov.pmix.IOperator;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Logger;

import javax.jws.HandlerChain;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceFeature;


@WebServiceClient(name = "OperatorService", targetNamespace = "http://www.pmix.gov", wsdlLocation = "file:wsdl/pmp.wsdl")
@HandlerChain(file="handlerConfiguration/handler-chain.xml")
public class PMPServiceReference extends Service //ClientBridge
{
	private final static URL PMP_WSDL_LOCATION;
	private final static Logger logger = Logger.getLogger(clientBridge.PMPServiceReference.class.getName());

	
	static
	{
		URL url = null;
		try
		{
			url = new URL("file:wsdl/pmpNoSecurity.wsdl"); 
		}
		catch (MalformedURLException e)
		{
			logger.warning("Failed to create URL for the specified wsdl Location, retrying as a local file");
			logger.warning(e.getMessage());
		}
		finally
		{
			url = null;
		}
		
		PMP_WSDL_LOCATION = url;
	}

	
	public PMPServiceReference(URL wsdlLocation, QName serviceName) throws MalformedURLException
	{
		super(wsdlLocation, serviceName);
	}

	
	public PMPServiceReference()throws MalformedURLException
	{
		super(PMP_WSDL_LOCATION, new QName("http://www.pmix.gov", "pmp"));
	}

	
	@WebEndpoint(name = "WsBasicProfile")
	public IOperator getWsBasicProfile()
	{
		return super.getPort(new QName("http://www.pmix.gov", "WsBasicProfile"), IOperator.class);
	}

	
	@WebEndpoint(name = "WsBasicProfile")
	public IOperator getWsBasicProfile(WebServiceFeature... features)
	{
		return super.getPort(new QName("http://www.pmix.gov", "WsBasicProfile"), IOperator.class, features);
	}

}
