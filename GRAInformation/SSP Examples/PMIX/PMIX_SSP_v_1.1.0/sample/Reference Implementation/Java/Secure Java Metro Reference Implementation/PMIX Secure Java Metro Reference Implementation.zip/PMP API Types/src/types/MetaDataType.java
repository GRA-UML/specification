
package types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MetaDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MetaDataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Requestor" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RequestorRole" type="{http://www.pmix.gov}RoleType"/>
 *         &lt;element name="RoutingData" type="{http://www.pmix.gov}RoutingDataType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MetaDataType", propOrder = {
    "requestor",
    "requestorRole",
    "routingData"
})
public class MetaDataType {

    @XmlElement(name = "Requestor", required = true, nillable = true)
    protected String requestor;
    @XmlElement(name = "RequestorRole", required = true)
    protected RoleType requestorRole;
    @XmlElement(name = "RoutingData", required = true, nillable = true)
    protected RoutingDataType routingData;

    /**
     * Gets the value of the requestor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestor() {
        return requestor;
    }

    /**
     * Sets the value of the requestor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestor(String value) {
        this.requestor = value;
    }

    /**
     * Gets the value of the requestorRole property.
     * 
     * @return
     *     possible object is
     *     {@link RoleType }
     *     
     */
    public RoleType getRequestorRole() {
        return requestorRole;
    }

    /**
     * Sets the value of the requestorRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link RoleType }
     *     
     */
    public void setRequestorRole(RoleType value) {
        this.requestorRole = value;
    }

    /**
     * Gets the value of the routingData property.
     * 
     * @return
     *     possible object is
     *     {@link RoutingDataType }
     *     
     */
    public RoutingDataType getRoutingData() {
        return routingData;
    }

    /**
     * Sets the value of the routingData property.
     * 
     * @param value
     *     allowed object is
     *     {@link RoutingDataType }
     *     
     */
    public void setRoutingData(RoutingDataType value) {
        this.routingData = value;
    }

}
