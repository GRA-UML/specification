package client;

import javax.swing.JFrame;

public class ClientApplication
{
	public static void main(String[] args) throws Exception
	{
		JFrame frame = null;

		try
		{
			com.sun.xml.ws.transport.http.client.HttpTransportPipe.dump = true;
			
			frame = new JFrame("PMP");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().add(new ClientUI());
			frame.pack();
			frame.setVisible(true);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			frame = null;
		}
	}
}
