/**
 * PmpMessageReceiverInOut.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.4  Built on : Dec 19, 2010 (08:18:42 CET)
 */
package gov.pmix.www;

import java.util.ArrayList;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.soap.SOAPHeaderBlock;


import utilities.Helper;
import types.*;

@SuppressWarnings("unused")
public class PmpMessageReceiverInOut extends
		org.apache.axis2.receivers.AbstractInOutMessageReceiver 
		{

	public void invokeBusinessLogic(
			org.apache.axis2.context.MessageContext msgContext,
			org.apache.axis2.context.MessageContext newMsgContext)
			throws org.apache.axis2.AxisFault 
	{
		try 
		{

			// get the implementation class for the Web Service
			Object obj = getTheImplementationObject(msgContext);
			
			Operator operator = (Operator) obj;
			// Out Envelope
			org.apache.axiom.soap.SOAPEnvelope envelope = null;
			// Find the axisOperation that has been set by the Dispatch phase.
			org.apache.axis2.description.AxisOperation op = msgContext.getOperationContext().getAxisOperation();
			if (op == null) 
			{
				throw new org.apache.axis2.AxisFault(
						"Operation is not located, if this is doclit style the SOAP-ACTION should specified via the SOAP Action to use the RawXMLProvider");
			}

			java.lang.String methodName;
			if ((op.getName() != null)
					&& ((methodName = org.apache.axis2.util.JavaUtils
							.xmlNameToJavaIdentifier(op.getName()
									.getLocalPart())) != null)) {

				if ("receiveDeferredPrescriptionDrugHistory".equals(methodName)) 
				{

					
					AcknowledgementType acknowledgementType = null;
					ResponseStatusType responseStatus = Helper.ReturnResponseStatus(msgContext);
					RoutingDataType routingData = Helper.ReturnRoutingData(msgContext);
					ResponseType wrappedParam = (ResponseType) fromOM(
							msgContext.getEnvelope().getBody()
									.getFirstElement(),
							ResponseType.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					acknowledgementType =

						operator.receiveDeferredPrescriptionDrugHistory(wrappedParam, responseStatus, routingData);

					envelope = toEnvelope(getSOAPFactory(msgContext),
							acknowledgementType, false);
				} 
				else

				if ("providePrescriptionDrugHistory".equals(methodName)) 
				{

					ResponseType response = null;
					ResponseStatus responseStatus = null;
					MetaData metaData = null;
					RequestType request = null;
						
					responseStatus = new ResponseStatus();
					
					metaData =	Helper.ReturnMetaData(msgContext);
					
					request = (RequestType) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(),
							RequestType.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					response =	operator.providePrescriptionDrugHistory(request, metaData, responseStatus);
					
					envelope = toEnvelope(getSOAPFactory(msgContext),response, false);
					
					envelope.getHeader().addChild(toOM(responseStatus, true));
					
					response = null;
					responseStatus = null;
					metaData = null;
					request = null;
						
				} 
				else 
				{
					throw new java.lang.RuntimeException("method not found");
				}
				newMsgContext.setEnvelope(envelope);
			}
		} 
		catch (java.lang.Exception e) 
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
	}

	
	private org.apache.axiom.om.OMElement toOM(ResponseType param,boolean optimizeContent)
		throws org.apache.axis2.AxisFault 
			{

		try 
		{
			return param.getOMElement(ResponseType.MY_QNAME,
					org.apache.axiom.om.OMAbstractFactory.getOMFactory());
		} 
		catch (org.apache.axis2.databinding.ADBException e) 
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}

	}


	private org.apache.axiom.om.OMElement toOM(AcknowledgementType param, boolean optimizeContent)
			throws org.apache.axis2.AxisFault 
			{

		try 
		{
			return param.getOMElement(
					AcknowledgementType.MY_QNAME,
					org.apache.axiom.om.OMAbstractFactory.getOMFactory());
		} 
		catch (org.apache.axis2.databinding.ADBException e) 
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}

	}

	private org.apache.axiom.om.OMElement toOM(
			ResponseStatus param, boolean optimizeContent)
			throws org.apache.axis2.AxisFault 
			{

		try 
		{
			return param.getOMElement(ResponseStatus.MY_QNAME,
					org.apache.axiom.om.OMAbstractFactory.getOMFactory());
		} 
		catch (org.apache.axis2.databinding.ADBException e) 
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}

	}

	private org.apache.axiom.om.OMElement toOM(RoutingData param,
			boolean optimizeContent) throws org.apache.axis2.AxisFault 
			{

		try
		{
			return param.getOMElement(RoutingData.MY_QNAME,
					org.apache.axiom.om.OMAbstractFactory.getOMFactory());
		} 
		catch (org.apache.axis2.databinding.ADBException e) 
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}

	}

	private org.apache.axiom.om.OMElement toOM(
			Acknowledgement param, boolean optimizeContent)
			throws org.apache.axis2.AxisFault 
			{

		try 
		{
			return param.getOMElement(Acknowledgement.MY_QNAME,
					org.apache.axiom.om.OMAbstractFactory.getOMFactory());
		} 
		catch (org.apache.axis2.databinding.ADBException e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}

	}

	private org.apache.axiom.om.OMElement toOM(RequestType param,
			boolean optimizeContent) throws org.apache.axis2.AxisFault
			{

		try 
		{
			return param.getOMElement(RequestType.MY_QNAME,
					org.apache.axiom.om.OMAbstractFactory.getOMFactory());
		} 
		catch (org.apache.axis2.databinding.ADBException e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}

	}

	private org.apache.axiom.om.OMElement toOM(MetaData param,
			boolean optimizeContent) throws org.apache.axis2.AxisFault {

		try 
		{
			return param.getOMElement(MetaData.MY_QNAME,
					org.apache.axiom.om.OMAbstractFactory.getOMFactory());
		} 
		catch (org.apache.axis2.databinding.ADBException e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}

	}

	private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
			org.apache.axiom.soap.SOAPFactory factory,
			AcknowledgementType param, boolean optimizeContent)
			throws org.apache.axis2.AxisFault {
		try
		{
			org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory
					.getDefaultEnvelope();

			emptyEnvelope.getBody()
					.addChild(
							param.getOMElement(
									AcknowledgementType.MY_QNAME,
									factory));

			return emptyEnvelope;
		} 
		catch (org.apache.axis2.databinding.ADBException e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
	}

	private AcknowledgementType wrapReceiveDeferredPrescriptionDrugHistory()
	{
		AcknowledgementType wrappedElement = new AcknowledgementType();
		return wrappedElement;
	}

	private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
			org.apache.axiom.soap.SOAPFactory factory,
			ResponseType param, boolean optimizeContent)
			throws org.apache.axis2.AxisFault 
			{
		try 
		{
			org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory
					.getDefaultEnvelope();

			emptyEnvelope.getBody().addChild(
					param.getOMElement(ResponseType.MY_QNAME,
							factory));

			return emptyEnvelope;
		} 
		catch (org.apache.axis2.databinding.ADBException e) 
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
	}

	private ResponseType wrapProvidePrescriptionDrugHistory()
	{
		ResponseType wrappedElement = new ResponseType();
		return wrappedElement;
	}

	/**
	 * get the default envelope
	 */
	private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
			org.apache.axiom.soap.SOAPFactory factory) 
	{
		return factory.getDefaultEnvelope();
	}

	@SuppressWarnings("rawtypes")
	private java.lang.Object fromOM(org.apache.axiom.om.OMElement param,
			java.lang.Class type, java.util.Map extraNamespaces)
			throws org.apache.axis2.AxisFault 
			{

		try {

			if (ResponseType.class.equals(type)) 
			{

				return ResponseType.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (AcknowledgementType.class.equals(type))
			{

				return AcknowledgementType.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (ResponseStatus.class.equals(type))
			{

				return ResponseStatus.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (RoutingData.class.equals(type)) 
			{

				return RoutingData.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (Acknowledgement.class.equals(type)) 
			{

				return Acknowledgement.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (RequestType.class.equals(type))
			{

				return RequestType.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (ResponseType.class.equals(type))
			{

				return ResponseType.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (MetaData.class.equals(type)) 
			{

				return MetaData.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (ResponseStatus.class.equals(type)) 
			{

				return ResponseStatus.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (RoutingData.class.equals(type)) 
			{

				return RoutingData.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

		} 
		catch (java.lang.Exception e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
		return null;
	}

	/**
	 * A utility method that copies the namepaces from the SOAPEnvelope
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private java.util.Map getEnvelopeNamespaces(
			org.apache.axiom.soap.SOAPEnvelope env)
	{
		java.util.Map returnMap = new java.util.HashMap();
		java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();
		while (namespaceIterator.hasNext()) {
			org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace) namespaceIterator
					.next();
			returnMap.put(ns.getPrefix(), ns.getNamespaceURI());
		}
		return returnMap;
	}

	private org.apache.axis2.AxisFault createAxisFault(java.lang.Exception e) {
		org.apache.axis2.AxisFault f;
		Throwable cause = e.getCause();
		if (cause != null)
		{
			f = new org.apache.axis2.AxisFault(e.getMessage(), cause);
		} 
		else 
		{
			f = new org.apache.axis2.AxisFault(e.getMessage());
		}
		return f;
	}

}// end of class
