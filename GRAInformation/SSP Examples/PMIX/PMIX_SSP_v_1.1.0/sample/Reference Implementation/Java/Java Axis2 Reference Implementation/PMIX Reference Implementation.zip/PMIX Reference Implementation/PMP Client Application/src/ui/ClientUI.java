package ui;

import javax.swing.JFrame;


public class ClientUI
{
    // ----------------------------------------------------------
    /**
     * The main method for the package.
     * @param args String arguments
     */
    public static void main(String[] args)
    {
        JFrame frame = new JFrame("PMP");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.getContentPane().add(new UIPanel());

        frame.pack();
        frame.setVisible(true);
    }
}
