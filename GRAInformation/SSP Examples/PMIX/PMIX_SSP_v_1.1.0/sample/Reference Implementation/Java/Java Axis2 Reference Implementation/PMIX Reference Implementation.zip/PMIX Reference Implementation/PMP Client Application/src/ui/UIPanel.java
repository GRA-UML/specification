package ui;


import gov.pmix.www.OperatorServiceStub;
import gov.pmix.www.OperatorServiceStub.ResponseStatusType;
import gov.pmix.www.OperatorServiceStub.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.*;
import java.lang.String;

import org.apache.axis2.databinding.ADBBean;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;

public class UIPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JPanel controlPanel;

	private JButton provide;

	private JButton receive;

	private JLabel stateID;

	private JLabel messageID;

	private JLabel data;

	private JTextField stateIDText;

	private JTextField messageIDText;

	private JTextField dataText;

	// ----------------------------------------------------------
	/**
	 * Constructor creates the control panel and initializes UIPanel.
	 */
	public UIPanel() 
	{
		setLayout(new BorderLayout());
		setBackground(Color.white);
		setPreferredSize(new Dimension(500, 400));
		createControlPanel();
	}

	// ----------------------------------------------------------
	/**
	 * Creates the control panel to be placed in the JPanel. It includes the
	 * definitions for the buttons and their action listeners.
	 */
	public void createControlPanel() 
	{
		controlPanel = new JPanel();
		controlPanel.setName("controlPanel");
		controlPanel.setPreferredSize(new Dimension(500, 400));
		controlPanel.setBackground(Color.white);
		add(controlPanel, BorderLayout.NORTH);
		
		stateID = new JLabel("State ID: ");
		stateID.setName("stateID");

		stateIDText = new JTextField("OH");
		stateIDText.setName("stateIDText");
		stateIDText.setPreferredSize(new Dimension(380, 20));

		messageID = new JLabel("Message ID:");
		messageID.setName("messageID");

		messageIDText = new JTextField("KY123456789");
		messageIDText.setName("messageIDText");
		messageIDText.setPreferredSize(new Dimension(390, 20));

		data = new JLabel("Data:");
		data.setName("data");
		data.setPreferredSize(new Dimension(390, 20));

		dataText = new JTextField("Test Data");
		dataText.setName("dataText");
		dataText.setPreferredSize(new Dimension(450, 250));
		
		provide = new JButton("Provide");
		provide.setName("provide");
		provide.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					provideAction();
				} 
				catch (Exception e1) 
				{
					e1.printStackTrace();
				}
			}
		});

		receive = new JButton("Receive");
		receive.setName("receive");
		receive.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					receiveAction();
				} 
				catch (Exception e1) 
				{
					e1.printStackTrace();
				}
			}
		});

		controlPanel.add(stateID);
		controlPanel.add(stateIDText);
		controlPanel.add(messageID);
		controlPanel.add(messageIDText);
		controlPanel.add(data);
		controlPanel.add(dataText);
		controlPanel.add(provide);
		controlPanel.add(receive);

	}

	// ----------------------------------------------------------
	/**
	 * A method to be implemented by the actionListener of Provide button..
	 * 
	 * @throws Exception
	 */
	public void provideAction() 
	{
		Configuration config = null;
		String clientAddress = "";
		String Requestor = "";
		String RequestingState = "";
		ResponseType response = null;
		ResponseStatusType status;
		RequestType requestType = null;
		MetaData metaData = null;
		MetaDataType data = null;
		
		try 
		{
			config = new PropertiesConfiguration("client.properties");
			clientAddress = config.getString("address");
			Requestor = config.getString("Requestor");
			RequestingState = config.getString("RequestingState");
			
			OperatorServiceStub stub = new OperatorServiceStub(clientAddress);

			requestType = (RequestType) getTestObject(RequestType.class);
			requestType.setRequestData(dataText.getText());
			metaData = (MetaData) getTestObject(MetaData.class);
			data = new MetaDataType();
			
			data.setRequestor(Requestor);
			RoleType role = new RoleType();

			role.setRoleType(RoleType._Examiner);
			data.setRequestorRole(role);
			

			RoutingDataType dataType = new RoutingDataType();
			dataType.setDisclosingState(stateIDText.getText());
			dataType.setRequestID(messageIDText.getText());
			dataType.setRequestingState(RequestingState);

			data.setRoutingData(dataType);

			metaData.setMetaData(data);
			
			response = stub.providePrescriptionDrugHistory(requestType, metaData);
			status = response.getResponseStatus();

	     	JOptionPane.showMessageDialog(null, "Status: " + status, "PMP Client", JOptionPane.OK_OPTION);
	     	
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		} 
		finally 
		{
			config = null;
			clientAddress = null;
		}
	}

	// ----------------------------------------------------------
	/**
	 * A method to be implemented by the actionListener of Previous button..
	 * 
	 * @throws Exception
	 */
	public void receiveAction() throws Exception {

		Configuration config = null;
		String clientAddress = "";
		AcknowledgementType acknowledgement = new AcknowledgementType();
		boolean acknowledgementStatus;
		ResponseType responseType = null;
		RoutingData routingData = null;
		RoutingDataType type = null;
		ResponseStatus responseStatus = null;
		ResponseStatusType status = null;
		
		try 
		{
			config = new PropertiesConfiguration("client.properties");
			clientAddress = config.getString("address");
			OperatorServiceStub stub = new OperatorServiceStub(clientAddress);

			responseType = (ResponseType) getTestObject(ResponseType.class);
			responseType.setResponseData("Response");
			responseStatus = (ResponseStatus) getTestObject(ResponseStatus.class);
			status = new ResponseStatusType(ResponseStatusType._Deferred, true);

			responseStatus.setResponseStatus(status);

			routingData = (RoutingData) getTestObject(RoutingData.class);

			type = new RoutingDataType();
			type.setDisclosingState(stateIDText.getText());
			type.setRequestID(messageIDText.getText());
			type.setRequestingState("MA");
			routingData.setRoutingData(type);

			acknowledgement = stub.receiveDeferredPrescriptionDrugHistory
			(responseType, responseStatus, routingData);
			
			acknowledgementStatus = acknowledgement.getAcknowledgement();
			
			JOptionPane.showMessageDialog(null, "Status: "+ acknowledgementStatus,
					"PMP Client", JOptionPane.OK_OPTION);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			config = null;
			clientAddress = null;
		}
	}

	@SuppressWarnings("rawtypes")
	public ADBBean getTestObject(Class type) throws Exception 
	{
		return (ADBBean) type.newInstance();
	}
}
