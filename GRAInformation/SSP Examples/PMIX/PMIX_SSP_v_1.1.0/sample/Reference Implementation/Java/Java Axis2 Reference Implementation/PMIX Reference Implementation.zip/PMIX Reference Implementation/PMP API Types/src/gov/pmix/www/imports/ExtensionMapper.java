/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.4  Built on : Dec 19, 2010 (08:19:26 CET)
 */

package gov.pmix.www.imports;

/**
 * ExtensionMapper class
 */

public class ExtensionMapper
{

	public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
			java.lang.String typeName, javax.xml.stream.XMLStreamReader reader)
			throws java.lang.Exception
	{

		if ("http://schemas.microsoft.com/2003/10/Serialization/"
				.equals(namespaceURI) && "guid".equals(typeName))
		{

			return com.microsoft.schemas._2003._10.serialization.Guid.Factory
					.parse(reader);

		}

		if ("http://schemas.microsoft.com/2003/10/Serialization/"
				.equals(namespaceURI) && "duration".equals(typeName))
		{

			return com.microsoft.schemas._2003._10.serialization.Duration.Factory
					.parse(reader);

		}

		if ("http://schemas.microsoft.com/2003/10/Serialization/"
				.equals(namespaceURI) && "char".equals(typeName))
		{

			return com.microsoft.schemas._2003._10.serialization._char.Factory
					.parse(reader);

		}

		if ("http://www.pmix.gov".equals(namespaceURI)
				&& "ResponseStatusType".equals(typeName))
		{

			return types.ResponseStatusType.Factory.parse(reader);

		}

		if ("http://www.pmix.gov".equals(namespaceURI)
				&& "MetaDataType".equals(typeName))
		{

			return types.MetaDataType.Factory.parse(reader);

		}

		if ("http://www.pmix.gov".equals(namespaceURI)
				&& "RoutingDataType".equals(typeName))
		{

			return types.RoutingDataType.Factory.parse(reader);

		}

		if ("http://www.pmix.gov".equals(namespaceURI)
				&& "RoleType".equals(typeName))
		{

			return types.RoleType.Factory.parse(reader);

		}

		throw new org.apache.axis2.databinding.ADBException("Unsupported type "
				+ namespaceURI + " " + typeName);
	}

}
