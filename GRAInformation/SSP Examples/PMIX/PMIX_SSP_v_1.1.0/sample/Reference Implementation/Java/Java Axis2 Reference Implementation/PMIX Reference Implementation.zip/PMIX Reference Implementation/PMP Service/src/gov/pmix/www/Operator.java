package gov.pmix.www;

import javax.jws.WebService;
import types.*;

@WebService
public class Operator implements IOperator
{

	public AcknowledgementType receiveDeferredPrescriptionDrugHistory(ResponseType responseType, 
			ResponseStatusType responseStatus, RoutingDataType routingData) 
	{
		AcknowledgementType ReturnValue = new AcknowledgementType();
		String messageID = "";
		String stateID = "";

		try 
		{
			if(routingData != null && routingData.getRequestingState() != null)
			{
			stateID = routingData.getRequestingState();
			}
			
			if(routingData != null && routingData.getRequestID() != null)
			{
            messageID = routingData.getRequestID();
			}

            // Insert processing code here.

            // 1. Verify response data format

            // 2. If response ok, then send Acknowledgement == true
            
            ReturnValue.setAcknowledgement(true); //temporary return value

            // 3. If response NOT ok, then send Acknowledgement == false

            // 4. Process response data

            // 5. If response status == not found, then ...

            // 6. If response status == provided, then ...
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally
		{
			messageID = null;
			stateID = null;
		}
		return (ReturnValue);
	}


	public ResponseType providePrescriptionDrugHistory(RequestType requestType, 
			MetaData metaData, ResponseStatus responseStatus) 
	{
		ResponseType ReturnValue = new ResponseType();
		String messageID = "";
		String requestingState = "";
		try 
		{
			ReturnValue.setResponseData("Test Data");
			
			if(metaData != null && 
				metaData.getMetaData() != null && 
				metaData.getMetaData().getRoutingData() != null &&
				metaData.getMetaData().getRoutingData().getRequestingState() != null)
			{
				requestingState = metaData.getMetaData().getRoutingData().getRequestingState();
			}
			
			if(metaData != null && 
					metaData.getMetaData() != null &&
					metaData.getMetaData().getRoutingData() != null &&
					metaData.getMetaData().getRoutingData().getRequestID() != null)
			{
				messageID = metaData.getMetaData().getRoutingData().getRequestID();
				
			}
			
            
             // Insert processing code here:

                 // 1. Validate Request

                 // 2. Conduct database search 

                 // 3. Format response data

                 // 4. Set the ResponseStatus type (NotFound, Deferred, Provided)
                 responseStatus.setResponseStatus(ResponseStatusType.NotFound);  //temporary Status

                 // 5. If "Provided", then include the Response Data

                 // 6. If "Deferred", then queue the request for additional processing
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		} 
		finally 
		{
			messageID = null;
			requestingState = null;
		}

		return ReturnValue;
	}
}
