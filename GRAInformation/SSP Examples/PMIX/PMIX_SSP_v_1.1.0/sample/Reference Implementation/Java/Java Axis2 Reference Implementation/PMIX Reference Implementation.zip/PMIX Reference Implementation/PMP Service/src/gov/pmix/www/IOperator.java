/**
 * PmpSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.4  Built on : Dec 19, 2010 (08:18:42 CET)
 */
package gov.pmix.www;

import types.*;


/**
 * PmpSkeletonInterface java skeleton interface for the axisService
 */

public interface IOperator {

	public AcknowledgementType receiveDeferredPrescriptionDrugHistory(ResponseType responseData,
			ResponseStatusType responseStatus, RoutingDataType routingData);


	public ResponseType providePrescriptionDrugHistory(RequestType requestData, 
			MetaData metaData, ResponseStatus responseStatus);

}
