package utilities;



import java.util.ArrayList;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.soap.SOAPHeaderBlock;

import types.Acknowledgement;
import types.AcknowledgementType;
import types.MetaData;
import types.RequestType;
import types.ResponseStatus;
import types.ResponseStatusType;
import types.ResponseType;
import types.RoutingData;
import types.RoutingDataType;


public class Helper
{
	@SuppressWarnings({ "rawtypes", "unused" })
	public static MetaData ReturnMetaData(
			org.apache.axis2.context.MessageContext msgContext)
			throws org.apache.axis2.AxisFault
	{
		MetaData metadata = null;
		OMElement metaDataElement = null;
		ArrayList headerBlocks = null;
		try
		{
			headerBlocks = msgContext.getEnvelope().getHeader()
					.getHeaderBlocksWithNSURI("http://www.pmix.gov");
			for (int i = 0; i < headerBlocks.size(); i++)
			{
				SOAPHeaderBlock headerBlock = null;
				headerBlock = (SOAPHeaderBlock) headerBlocks.get(i);
				metaDataElement = headerBlock.cloneOMElement();
				break;
			}
			metadata = (MetaData) fromOM(metaDataElement, MetaData.class,
					getEnvelopeNamespaces(msgContext.getEnvelope()));
		}
		catch (java.lang.Exception e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
		finally
		{
			headerBlocks = null;
			metaDataElement = null;
		}
		return metadata;
	}

	@SuppressWarnings({ "rawtypes", "unused" })
	public static ResponseStatusType ReturnResponseStatus(
			org.apache.axis2.context.MessageContext msgContext)
			throws org.apache.axis2.AxisFault
	{
		ResponseStatusType responseStatus = null;
		OMElement responseStatusElement = null;
		ArrayList headerBlocks = null;
		try
		{
			headerBlocks = msgContext.getEnvelope().getHeader()
					.getHeaderBlocksWithNSURI("http://www.pmix.gov");
			for (int i = 0; i < headerBlocks.size(); i++)
			{
				SOAPHeaderBlock headerBlock = null;
				headerBlock = (SOAPHeaderBlock) headerBlocks.get(i);
				responseStatusElement = headerBlock.cloneOMElement();
				break;
			}
			responseStatus = (ResponseStatusType) fromOM(responseStatusElement,
					ResponseStatusType.class,
					getEnvelopeNamespaces(msgContext.getEnvelope()));
		}
		catch (java.lang.Exception e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
		finally
		{
			headerBlocks = null;
			responseStatusElement = null;
		}
		return responseStatus;
	}

	@SuppressWarnings({ "rawtypes", "unused" })
	public static RoutingDataType ReturnRoutingData(
			org.apache.axis2.context.MessageContext msgContext)
			throws org.apache.axis2.AxisFault
	{
		RoutingDataType routingData = null;
		OMElement routingDataElement = null;
		ArrayList headerBlocks = null;
		try
		{
			headerBlocks = msgContext.getEnvelope().getHeader()
					.getHeaderBlocksWithNSURI("http://www.pmix.gov");
			for (int i = 0; i < headerBlocks.size(); i++)
			{
				SOAPHeaderBlock headerBlock = null;
				headerBlock = (SOAPHeaderBlock) headerBlocks.get(i);
				routingDataElement = headerBlock.cloneOMElement();
				break;
			}
			routingData = (RoutingDataType) fromOM(routingDataElement,
					RoutingDataType.class,
					getEnvelopeNamespaces(msgContext.getEnvelope()));
		}
		catch (java.lang.Exception e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
		finally
		{
			headerBlocks = null;
			routingDataElement = null;
		}
		return routingData;
	}

	@SuppressWarnings("rawtypes")
	public static java.lang.Object fromOM(org.apache.axiom.om.OMElement param,
			java.lang.Class type, java.util.Map extraNamespaces)
			throws org.apache.axis2.AxisFault
	{

		try
		{

			if (ResponseType.class.equals(type))
			{

				return ResponseType.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (AcknowledgementType.class.equals(type))
			{

				return AcknowledgementType.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (ResponseStatus.class.equals(type))
			{

				return ResponseStatus.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (RoutingData.class.equals(type))
			{

				return RoutingData.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (Acknowledgement.class.equals(type))
			{

				return Acknowledgement.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (RequestType.class.equals(type))
			{

				return RequestType.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (ResponseType.class.equals(type))
			{

				return ResponseType.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (MetaData.class.equals(type))
			{

				return MetaData.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (ResponseStatus.class.equals(type))
			{

				return ResponseStatus.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

			if (RoutingData.class.equals(type))
			{

				return RoutingData.Factory.parse(param
						.getXMLStreamReaderWithoutCaching());

			}

		}
		catch (java.lang.Exception e)
		{
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static java.util.Map getEnvelopeNamespaces(
			org.apache.axiom.soap.SOAPEnvelope env)
	{
		java.util.Map returnMap = new java.util.HashMap();
		java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();
		while (namespaceIterator.hasNext())
		{
			org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace) namespaceIterator
					.next();
			returnMap.put(ns.getPrefix(), ns.getNamespaceURI());
		}
		return returnMap;
	}
}
