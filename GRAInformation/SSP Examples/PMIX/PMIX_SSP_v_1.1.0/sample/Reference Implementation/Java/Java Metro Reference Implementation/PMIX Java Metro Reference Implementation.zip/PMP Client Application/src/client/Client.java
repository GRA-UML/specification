package client;

import gov.pmix.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.*;
import javax.xml.bind.JAXBElement;
import javax.xml.ws.Holder;

import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.util.Properties;

public class Client extends JPanel
{

	private static final long serialVersionUID = 1L;

	private JPanel controlPanel;

	private JButton provide;

	private JButton receive;

	private JLabel stateID;

	private JLabel messageID;

	private JLabel data;

	private JTextField stateIDText;

	private JTextField messageIDText;

	private JTextField dataText;

	// ----------------------------------------------------------
	/**
	 * Constructor creates the control panel and initializes UIPanel.
	 */
	public Client()
	{
		setLayout(new BorderLayout());
		setBackground(Color.white);
		setPreferredSize(new Dimension(500, 400));
		createControlPanel();
	}

	// ----------------------------------------------------------
	/**
	 * Creates the control panel to be placed in the JPanel. It includes the
	 * definitions for the buttons and their action listeners.
	 */
	public void createControlPanel()
	{
		controlPanel = new JPanel();
		controlPanel.setName("controlPanel");
		controlPanel.setPreferredSize(new Dimension(500, 400));
		controlPanel.setBackground(Color.white);
		add(controlPanel, BorderLayout.NORTH);

		stateID = new JLabel("State ID: ");
		stateID.setName("stateID");

		stateIDText = new JTextField("OH");
		stateIDText.setName("stateIDText");
		stateIDText.setPreferredSize(new Dimension(380, 20));

		messageID = new JLabel("Message ID:");
		messageID.setName("messageID");

		messageIDText = new JTextField("KY123456789");
		messageIDText.setName("messageIDText");
		messageIDText.setPreferredSize(new Dimension(390, 20));

		data = new JLabel("Data:");
		data.setName("data");
		data.setPreferredSize(new Dimension(390, 20));

		dataText = new JTextField("Test Data");
		dataText.setName("dataText");
		dataText.setPreferredSize(new Dimension(450, 250));

		provide = new JButton("Provide");
		provide.setName("provide");
		provide.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					provideAction();
				}
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
			}
		});

		receive = new JButton("Receive");
		receive.setName("receive");
		receive.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					receiveAction();
				}
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
			}
		});

		controlPanel.add(stateID);
		controlPanel.add(stateIDText);
		controlPanel.add(messageID);
		controlPanel.add(messageIDText);
		controlPanel.add(data);
		controlPanel.add(dataText);
		controlPanel.add(provide);
		controlPanel.add(receive);
	}

	// ----------------------------------------------------------
	/**
	 * A method to be implemented by the actionListener of Provide button..
	 * 
	 * @throws MalformedURLException
	 */
	public void provideAction() throws MalformedURLException
	{

		Pmp_Service service = new Pmp_Service();
		Pmp pmp = service.getWsBasicProfile();
		RequestType request = new RequestType();
		MetaDataType metaData = new MetaDataType();
		RoutingDataType routingDataType = new RoutingDataType();
		Holder<ResponseStatusType> responseStatus = new Holder<ResponseStatusType>();
		Holder<RoutingDataType> routingData = new Holder<RoutingDataType>();

		try
		{
			// Read client.properties file
			FileInputStream is = new FileInputStream("client.properties");
			Properties prop = new Properties();
			prop.load(is);

			//Routing Data
			routingDataType.setDisclosingState(prop
					.getProperty("Disclosing_State"));
			routingDataType.setRequestID(messageIDText.getText());
			routingDataType.setRequestingState(stateIDText.getText());

			//Metadata
			metaData.setRequestor(prop.getProperty("Requestor"));
			metaData.setRequestorRole(RoleType.EXAMINER);
			metaData.setRoutingData(routingDataType);
			
			//Request
			com.microsoft.schemas._2003._10.serialization.ObjectFactory fact = new com.microsoft.schemas._2003._10.serialization.ObjectFactory();
			JAXBElement<String> string = fact.createString(dataText.getText());
			request.setRequestData(string);
			
			pmp.providePrescriptionDrugHistory(request, metaData, responseStatus, routingData);

			JOptionPane.showMessageDialog(null, "Status: " + responseStatus.value, "PMP Client",
					JOptionPane.INFORMATION_MESSAGE);
		}
		catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage()
					+ "\n" + e.toString(), "PMP Client",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	// ----------------------------------------------------------
	/**
	 * A method to be implemented by the actionListener of Previous button..
	 * 
	 * @throws Exception
	 */
	public void receiveAction() throws Exception
	{

		Pmp_Service service = new Pmp_Service();
		Pmp pmp = service.getWsBasicProfile();
		ResponseStatusType responseStatus = ResponseStatusType.DEFERRED;
		ResponseType response = new ResponseType();
		RoutingDataType routingData = new RoutingDataType();
		Holder<Boolean> acknowledgement = new Holder<Boolean>();

		try
		{

			FileInputStream is = new FileInputStream("client.properties");
			Properties prop = new Properties();
			prop.load(is);

			//Response
			com.microsoft.schemas._2003._10.serialization.ObjectFactory fact = new com.microsoft.schemas._2003._10.serialization.ObjectFactory();
			JAXBElement<String> string = fact.createString(dataText.getText());
			
			response.setResponseData(string);
			
			//Routing Data
			routingData.setDisclosingState(prop.getProperty("Disclosing_State"));
			routingData.setRequestID(messageIDText.getText());
			routingData.setRequestingState(stateIDText.getText());

			pmp.receiveDeferredPrescriptionDrugHistory(response,
					responseStatus, routingData, acknowledgement);

			JOptionPane.showMessageDialog(null, "Status: "
					+ acknowledgement.value, "PMP Client",
					JOptionPane.INFORMATION_MESSAGE);
		}
		catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage()
					+ "\n" + e.toString(), "PMP Client",
					JOptionPane.ERROR_MESSAGE);
		}

	}
}
