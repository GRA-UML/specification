package utilities;

import javax.xml.bind.JAXBElement;
import types.*;

public class Helper
{

	public static String ReturnRequestingState(RoutingDataType routingData)
	{
		String stateID = "";
		try
		{
			stateID = routingData.getRequestingState();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return stateID;
	}

	public static String ReturnRequestingState(MetaDataType metaData)
	{
		String stateID = "";
		try
		{
			if (metaData.getRoutingData() != null)
			{
				stateID = metaData.getRoutingData().getRequestingState();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return stateID;
	}

	public static String ReturnMessageID(MetaDataType metaData)
	{
		String messageID = "";
		try
		{
			if (metaData != null && metaData.getRoutingData() != null
					&& metaData.getRoutingData().getRequestID() != null)
			{
				messageID = metaData.getRoutingData().getRequestID();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return messageID;
	}

	public static String ReturnRelatesTo(RoutingDataType routingData)
	{
		String messageID = "";
		try
		{
			if (routingData != null && routingData.getRequestID() != null)
			{
				messageID = routingData.getRequestID();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return messageID;
	}

	@SuppressWarnings("unused")
	private static JAXBElement<String> ReturnData(RequestType RequestData)
	{
		JAXBElement<String> data = null;
		try
		{
			if (RequestData != null)
			{
				data = RequestData.getRequestData();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return data;
	}

	@SuppressWarnings("unused")
	private static JAXBElement<String> ReturnData(ResponseType ResponseData)
	{
		JAXBElement<String> data = null;
		try
		{
			if (ResponseData != null)
			{
				data = ResponseData.getResponseData();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return data;
	}

}
