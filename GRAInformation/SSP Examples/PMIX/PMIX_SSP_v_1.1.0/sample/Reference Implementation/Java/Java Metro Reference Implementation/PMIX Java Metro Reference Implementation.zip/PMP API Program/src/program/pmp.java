package program;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.BindingType;
import javax.xml.ws.Holder;
import javax.xml.ws.soap.Addressing;

import contract.IPmp;

import types.*;
import utilities.*;

@WebService(serviceName = "pmp", targetNamespace = "http://www.pmix.gov", portName = "WsBasicProfile")
@BindingType(value="http://java.sun.com/xml/ns/jaxws/2003/05/soap/bindings/HTTP/")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@XmlSeeAlso({ program.ObjectFactory.class,
		com.microsoft.schemas._2003._10.serialization.ObjectFactory.class })
@Addressing(enabled = true)
public class pmp implements IPmp
{
	/**
	 * Auto generated method signature
	 * 
	 * @param responseType
	 */

	@WebMethod(operationName = "ProvidePrescriptionDrugHistory", action = "http://www.pmix.gov/pmp/ProvidePrescriptionDrugHistory")
	@WebResult(name = "ResponseType", targetNamespace = "http://www.pmix.gov", partName = "parameters")
	public ResponseType providePrescriptionDrugHistory(
			@WebParam(name = "RequestType", targetNamespace = "http://www.pmix.gov", partName = "parameters") RequestType parameters,
			@WebParam(name = "MetaData", targetNamespace = "http://www.pmix.gov", header = true, partName = "MetaData") MetaDataType metaData,
			@WebParam(name = "ResponseStatus", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "ResponseStatus") Holder<ResponseStatusType> responseStatus,
			@WebParam(name = "RoutingData", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "RoutingData") Holder<RoutingDataType> routingData)
	{
		ResponseType ReturnValue = new ResponseType();
		String messageID = "";
		String requestingState = "";
		try
		{
			requestingState = Helper.ReturnRequestingState(metaData);
			messageID = Helper.ReturnMessageID(metaData);

			com.microsoft.schemas._2003._10.serialization.ObjectFactory fact = 
				new com.microsoft.schemas._2003._10.serialization.ObjectFactory();   
			JAXBElement<String> string = fact.createString("Test Data");
			
			ReturnValue.setResponseData(string);
			
			responseStatus.value = ResponseStatusType.NOT_FOUND;

		} catch (Exception e)
		{
			e.printStackTrace();
		} finally
		{
			messageID = null;
			requestingState = null;
			System.out.println(messageID + " " + requestingState);
		}
		return ReturnValue;
	}

	@WebMethod(operationName = "ReceiveDeferredPrescriptionDrugHistory", action = "http://www.pmix.gov/pmp/ReceiveDeferredPrescriptionDrugHistory")
	@WebResult(name = "AcknowledgementType", targetNamespace = "http://www.pmix.gov", partName = "parameters")
	public AcknowledgementType receiveDeferredPrescriptionDrugHistory(
			@WebParam(name = "ResponseType", targetNamespace = "http://www.pmix.gov", partName = "parameters") ResponseType parameters,
			@WebParam(name = "ResponseStatus", targetNamespace = "http://www.pmix.gov", header = true, partName = "ResponseStatus") ResponseStatusType responseStatus,
			@WebParam(name = "RoutingData", targetNamespace = "http://www.pmix.gov", header = true, partName = "RoutingData") RoutingDataType routingData,
			@WebParam(name = "Acknowledgement", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "Acknowledgement") Holder<Boolean> acknowledgement)
	{
		AcknowledgementType ReturnValue = new AcknowledgementType();

		String messageID = "";
		String stateID = "";

		try
		{
			stateID = Helper.ReturnRequestingState(routingData);
			messageID = Helper.ReturnRelatesTo(routingData);

			acknowledgement.value = true; // temporary return value
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		} 
		finally
		{
			messageID = null;
			stateID = null;
		}

		return (ReturnValue);
	}

}
