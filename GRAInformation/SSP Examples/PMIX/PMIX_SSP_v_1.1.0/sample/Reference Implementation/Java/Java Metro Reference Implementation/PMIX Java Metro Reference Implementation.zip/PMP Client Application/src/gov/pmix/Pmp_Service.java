package gov.pmix;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceFeature;
import java.util.Properties;
import java.io.*;


@WebServiceClient(name = "OperatorService", targetNamespace = "http://www.pmix.gov")
public class Pmp_Service extends Service
{

	private final static URL PMP_WSDL_LOCATION;
	private final static Logger logger = Logger
			.getLogger(gov.pmix.Pmp_Service.class.getName());

	static
	{
		URL url = null;

		try
		{
			FileInputStream is = new FileInputStream("client.properties");
			Properties prop = new Properties();
			prop.load(is);
			String address = prop.getProperty("address");
			URL baseUrl;
			
			
			baseUrl = gov.pmix.Pmp_Service.class.getResource(".");
			url = new URL(baseUrl, address);
		}
		catch (MalformedURLException e)
		{
			logger.warning("Failed to create URL for the specified wsdl Location, retrying as a local file");
			logger.warning(e.getMessage());
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		PMP_WSDL_LOCATION = url;
	}

	public Pmp_Service(URL wsdlLocation, QName serviceName)
	{
		super(wsdlLocation, serviceName);
	}

	public Pmp_Service()
	{
		super(PMP_WSDL_LOCATION, new QName("http://www.pmix.gov", "pmp"));
	}

	@WebEndpoint(name = "WsBasicProfile")
	public Pmp getWsBasicProfile()
	{
		return super.getPort(
				new QName("http://www.pmix.gov", "WsBasicProfile"), Pmp.class);
	}

	@WebEndpoint(name = "WsBasicProfile")
	public Pmp getWsBasicProfile(WebServiceFeature... features)
	{
		return super.getPort(
				new QName("http://www.pmix.gov", "WsBasicProfile"), Pmp.class,
				features);
	}

}
