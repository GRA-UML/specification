package gov.pmix;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.Holder;
import javax.xml.ws.soap.Addressing;


@WebService(serviceName = "pmp", targetNamespace = "http://www.pmix.gov", portName = "WsBasicProfile")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE, style = SOAPBinding.Style.DOCUMENT)
@XmlSeeAlso({ gov.pmix.ObjectFactory.class,
		com.microsoft.schemas._2003._10.serialization.ObjectFactory.class })
@Addressing
public interface Pmp
{

	@WebMethod(operationName = "ProvidePrescriptionDrugHistory", action = "http://www.pmix.gov/pmp/ProvidePrescriptionDrugHistory")
	@WebResult(name = "ResponseType", targetNamespace = "http://www.pmix.gov", partName = "parameters")
	public ResponseType providePrescriptionDrugHistory(
			@WebParam(name = "RequestType", targetNamespace = "http://www.pmix.gov", partName = "parameters") RequestType parameters,
			@WebParam(name = "MetaData", targetNamespace = "http://www.pmix.gov", header = true, partName = "MetaData") MetaDataType metaData,
			@WebParam(name = "ResponseStatus", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "ResponseStatus") Holder<ResponseStatusType> responseStatus,
			@WebParam(name = "RoutingData", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "RoutingData") Holder<RoutingDataType> routingData);

	@WebMethod(operationName = "ReceiveDeferredPrescriptionDrugHistory", action = "http://www.pmix.gov/pmp/ReceiveDeferredPrescriptionDrugHistory")
	@WebResult(name = "AcknowledgementType", targetNamespace = "http://www.pmix.gov", partName = "parameters")
	public AcknowledgementType receiveDeferredPrescriptionDrugHistory(
			@WebParam(name = "ResponseType", targetNamespace = "http://www.pmix.gov", partName = "parameters") ResponseType parameters,
			@WebParam(name = "ResponseStatus", targetNamespace = "http://www.pmix.gov", header = true, partName = "ResponseStatus") ResponseStatusType responseStatus,
			@WebParam(name = "RoutingData", targetNamespace = "http://www.pmix.gov", header = true, partName = "RoutingData") RoutingDataType routingData,
			@WebParam(name = "Acknowledgement", targetNamespace = "http://www.pmix.gov", header = true, mode = WebParam.Mode.OUT, partName = "Acknowledgement") Holder<Boolean> acknowledgement);

}
