
package gov.pmix;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RoutingDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RoutingDataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DisclosingState" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RequestID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RequestingState" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RoutingDataType", propOrder = {
    "disclosingState",
    "requestID",
    "requestingState"
})
public class RoutingDataType {

    @XmlElement(name = "DisclosingState", required = true, nillable = true)
    protected String disclosingState;
    @XmlElement(name = "RequestID", required = true, nillable = true)
    protected String requestID;
    @XmlElement(name = "RequestingState", required = true, nillable = true)
    protected String requestingState;

    /**
     * Gets the value of the disclosingState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisclosingState() {
        return disclosingState;
    }

    /**
     * Sets the value of the disclosingState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisclosingState(String value) {
        this.disclosingState = value;
    }

    /**
     * Gets the value of the requestID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestID() {
        return requestID;
    }

    /**
     * Sets the value of the requestID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestID(String value) {
        this.requestID = value;
    }

    /**
     * Gets the value of the requestingState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestingState() {
        return requestingState;
    }

    /**
     * Sets the value of the requestingState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestingState(String value) {
        this.requestingState = value;
    }

}
