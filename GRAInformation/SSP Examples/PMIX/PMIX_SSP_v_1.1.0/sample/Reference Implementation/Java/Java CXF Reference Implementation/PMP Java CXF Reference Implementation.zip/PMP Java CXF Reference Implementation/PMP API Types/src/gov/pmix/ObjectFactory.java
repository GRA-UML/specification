
package gov.pmix;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the gov.pmix package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RoutingData_QNAME = new QName("http://www.pmix.gov", "RoutingData");
    private final static QName _MetaData_QNAME = new QName("http://www.pmix.gov", "MetaData");
    private final static QName _MetaDataType_QNAME = new QName("http://www.pmix.gov", "MetaDataType");
    private final static QName _RoleType_QNAME = new QName("http://www.pmix.gov", "RoleType");
    private final static QName _Acknowledgement_QNAME = new QName("http://www.pmix.gov", "Acknowledgement");
    private final static QName _ResponseStatusType_QNAME = new QName("http://www.pmix.gov", "ResponseStatusType");
    private final static QName _RoutingDataType_QNAME = new QName("http://www.pmix.gov", "RoutingDataType");
    private final static QName _ResponseStatus_QNAME = new QName("http://www.pmix.gov", "ResponseStatus");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: gov.pmix
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ResponseType }
     * 
     */
    public ResponseType createResponseType() {
        return new ResponseType();
    }

    /**
     * Create an instance of {@link AcknowledgementType }
     * 
     */
    public AcknowledgementType createAcknowledgementType() {
        return new AcknowledgementType();
    }

    /**
     * Create an instance of {@link RoutingDataType }
     * 
     */
    public RoutingDataType createRoutingDataType() {
        return new RoutingDataType();
    }

    /**
     * Create an instance of {@link MetaDataType }
     * 
     */
    public MetaDataType createMetaDataType() {
        return new MetaDataType();
    }

    /**
     * Create an instance of {@link RequestType }
     * 
     */
    public RequestType createRequestType() {
        return new RequestType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoutingDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.pmix.gov", name = "RoutingData")
    public JAXBElement<RoutingDataType> createRoutingData(RoutingDataType value) {
        return new JAXBElement<RoutingDataType>(_RoutingData_QNAME, RoutingDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MetaDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.pmix.gov", name = "MetaData")
    public JAXBElement<MetaDataType> createMetaData(MetaDataType value) {
        return new JAXBElement<MetaDataType>(_MetaData_QNAME, MetaDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MetaDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.pmix.gov", name = "MetaDataType")
    public JAXBElement<MetaDataType> createMetaDataType(MetaDataType value) {
        return new JAXBElement<MetaDataType>(_MetaDataType_QNAME, MetaDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.pmix.gov", name = "RoleType")
    public JAXBElement<RoleType> createRoleType(RoleType value) {
        return new JAXBElement<RoleType>(_RoleType_QNAME, RoleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.pmix.gov", name = "Acknowledgement")
    public JAXBElement<Boolean> createAcknowledgement(Boolean value) {
        return new JAXBElement<Boolean>(_Acknowledgement_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResponseStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.pmix.gov", name = "ResponseStatusType")
    public JAXBElement<ResponseStatusType> createResponseStatusType(ResponseStatusType value) {
        return new JAXBElement<ResponseStatusType>(_ResponseStatusType_QNAME, ResponseStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoutingDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.pmix.gov", name = "RoutingDataType")
    public JAXBElement<RoutingDataType> createRoutingDataType(RoutingDataType value) {
        return new JAXBElement<RoutingDataType>(_RoutingDataType_QNAME, RoutingDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResponseStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.pmix.gov", name = "ResponseStatus")
    public JAXBElement<ResponseStatusType> createResponseStatus(ResponseStatusType value) {
        return new JAXBElement<ResponseStatusType>(_ResponseStatus_QNAME, ResponseStatusType.class, null, value);
    }

}
