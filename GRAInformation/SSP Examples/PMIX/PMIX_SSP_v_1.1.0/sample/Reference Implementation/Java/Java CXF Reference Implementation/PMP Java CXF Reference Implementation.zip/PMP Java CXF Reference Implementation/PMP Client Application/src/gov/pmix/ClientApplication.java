package gov.pmix;

import javax.swing.JFrame;

public class ClientApplication
{
	public static void main(String[] args) throws Exception
	{
		JFrame frame = null;

		try
		{			
			frame = new JFrame("PMP");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().add(new ClientUI());
			frame.pack();
			frame.setVisible(true);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			frame = null;
		}
	}
}
