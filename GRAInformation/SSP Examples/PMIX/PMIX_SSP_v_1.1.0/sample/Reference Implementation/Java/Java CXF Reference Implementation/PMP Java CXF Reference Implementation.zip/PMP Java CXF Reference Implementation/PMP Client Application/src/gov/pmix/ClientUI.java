package gov.pmix;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.*;
import javax.xml.ws.Holder;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ClientUI extends JPanel
{
	private static final long serialVersionUID = 1L;

	private JPanel controlPanel;
	private JButton provide;
	private JButton receive;
	private JLabel stateIDLabel;
	private JLabel messageIDLabel;
	private JLabel dataLabel;
	private JTextField stateIDTextField;
	private JTextField messageIDTextField;
	private JTextField dataTextField;

	private String requestingState;
	private String requestor;
	private String address;

	private static ClientBridge clientBridge;

	// ----------------------------------------------------------
	/**
	 * Constructor creates the control panel and initializes UIPanel.
	 * 
	 * @throws Exception
	 */
	public ClientUI() throws Exception
	{
		clientBridge = new ClientBridge();
		FileInputStream is = null;
		Properties prop = new Properties();

		try
		{
			// Prepare JPanel
			setLayout(new BorderLayout());
			setBackground(Color.white);
			setPreferredSize(new Dimension(500, 400));
			createControlPanel();

			// Read properties file
			is = new FileInputStream("client.properties");
			prop.load(is);

			requestingState = prop.getProperty("RequestingState");
			requestor = prop.getProperty("Requestor");
			address = prop.getProperty("Address");
		}
		catch (IOException e)
		{
			throw e;
		}
		finally
		{
			is = null;
			prop = null;
		}
	}

	// ----------------------------------------------------------
	/**
	 * Creates the control panel to be placed in the JPanel. It includes the
	 * definitions for the buttons and their action listeners.
	 * 
	 * @throws Exception
	 */
	public void createControlPanel() throws Exception
	{
		Font textFont = null;
		Font labelFont = null;

		try
		{
			textFont = new Font("Georgia", Font.PLAIN, 12);
			labelFont = new Font("Georgia", Font.BOLD, 12);

			controlPanel = new JPanel();
			controlPanel.setName("controlPanel");
			controlPanel.setPreferredSize(new Dimension(500, 400));
			controlPanel.setBackground(Color.white);
			controlPanel.setFont(textFont);
			add(controlPanel, BorderLayout.WEST);

			stateIDLabel = new JLabel("Destination State ID: ");
			stateIDLabel.setName("stateID");
			stateIDLabel.setFont(labelFont);
			stateIDLabel.setForeground(Color.BLACK);

			stateIDTextField = new JTextField("TT");
			stateIDTextField.setName("stateIDText");
			stateIDTextField.setPreferredSize(new Dimension(322, 20));
			stateIDTextField.setFont(textFont);
			stateIDTextField.setForeground(Color.BLACK);

			messageIDLabel = new JLabel("Message ID:");
			messageIDLabel.setName("messageID");
			messageIDLabel.setFont(labelFont);
			messageIDLabel.setForeground(Color.BLACK);

			messageIDTextField = new JTextField("KY123456789");
			messageIDTextField.setName("messageIDText");
			messageIDTextField.setPreferredSize(new Dimension(390, 20));
			messageIDTextField.setFont(textFont);
			messageIDTextField.setForeground(Color.BLACK);

			dataLabel = new JLabel("Data:");
			dataLabel.setName("data");
			dataLabel.setPreferredSize(new Dimension(468, 20));
			dataLabel.setFont(labelFont);
			dataLabel.setForeground(Color.BLACK);

			dataTextField = new JTextField("Test Data");
			dataTextField.setName("dataText");
			dataTextField.setPreferredSize(new Dimension(450, 250));
			dataTextField.setFont(textFont);
			dataTextField.setForeground(Color.BLACK);

			provide = new JButton("Provide");
			provide.setName("provide");
			provide.setFont(labelFont);
			provide.setForeground(Color.BLACK);
			provide.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					provideAction();
				}
			});

			receive = new JButton("Receive");
			receive.setName("receive");
			receive.setFont(labelFont);
			receive.setForeground(Color.BLACK);
			receive.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					receiveAction();
				}
			});

			controlPanel.add(stateIDLabel, BorderLayout.WEST);
			controlPanel.add(stateIDTextField);
			controlPanel.add(messageIDLabel, BorderLayout.WEST);
			controlPanel.add(messageIDTextField);
			controlPanel.add(dataLabel, BorderLayout.WEST);
			controlPanel.add(dataTextField, BorderLayout.WEST);
			controlPanel.add(provide);
			controlPanel.add(receive);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			textFont = null;
			labelFont = null;
		}
	}

	// Move to Client Bridge
	public void provideAction()
	{
		RequestType request = new RequestType();
		MetaDataType metaData = new MetaDataType();
		RoutingDataType routingDataType = new RoutingDataType();
		RoleType roleType = RoleType.EXAMINER;
		Holder<ResponseStatusType> responseStatus = new Holder<ResponseStatusType>();
		Holder<RoutingDataType> routingData = new Holder<RoutingDataType>();
		ResponseType response = new ResponseType();
		String messageID;
		String disclosingState;
		String requestData;
		String displayMessage;

		try
		{
			// Retrieve information from UI
			requestData = dataTextField.getText();
			disclosingState = stateIDTextField.getText();
			messageID = messageIDTextField.getText();

			// Routing Data
			routingDataType.setDisclosingState(disclosingState);
			routingDataType.setRequestID(messageID);
			routingDataType.setRequestingState(requestingState);

			// Metadata
			metaData.setRequestor(requestor);
			metaData.setRequestorRole(roleType);
			metaData.setRoutingData(routingDataType);

			// Request
			request.setRequestData(requestData);

			response = clientBridge.ProvidePrescriptionDrugHistory(request,	metaData, responseStatus, routingData, address);

			displayMessage = "Response Status: " + responseStatus.value	+ "\n\n" + "Data from Client:" + "\n" + response.getResponseData();
			JOptionPane.showMessageDialog(null, displayMessage, "PMP Client", JOptionPane.INFORMATION_MESSAGE);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage()
					+ "\n" + e.toString(), "PMP Client",
					JOptionPane.ERROR_MESSAGE);
		}
		finally
		{
			request = null;
			metaData = null;
			responseStatus = null;
			routingData = null;
		}
	}

	// ----------------------------------------------------------
	/**
	 * A method to be implemented by the actionListener of Previous button..
	 * 
	 * @throws Exception
	 */
	public void receiveAction()
	{
		ResponseStatusType responseStatus = ResponseStatusType.DEFERRED;
		ResponseType response = new ResponseType();
		RoutingDataType routingData = new RoutingDataType();
		Holder<Boolean> acknowledgement = new Holder<Boolean>();
		AcknowledgementType acknowledgementResponse = new AcknowledgementType();
		String disclosingState;
		String messageID;
		String responseData;

		try
		{
			// Retrieve information from UI
			disclosingState = stateIDTextField.getText();
			messageID = messageIDTextField.getText();
			responseData = dataTextField.getText();

			// Response
			response.setResponseData(responseData);

			// Routing Data
			routingData.setDisclosingState(disclosingState);
			routingData.setRequestID(messageID);
			routingData.setRequestingState(requestingState);

			acknowledgementResponse = clientBridge.ReceiveDeferredPrescriptionDrugHistory(
					response, responseStatus, routingData, acknowledgement, address);
				
			JOptionPane.showMessageDialog(null, "Status: " + acknowledgement.value, "PMP Client",
					JOptionPane.INFORMATION_MESSAGE);
		}
		catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage()
					+ "\n" + e.toString(), "PMP Client",
					JOptionPane.ERROR_MESSAGE);
		}
		finally
		{
			response = null;
			responseStatus = null;
			routingData = null;
			acknowledgement = null;
		}
	}
}
