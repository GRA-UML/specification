For SIRS sample XML instances see the samples included in the IEPD
package at SIRS_SSP_v_0_1_0\artifacts\service model\information model\SIRS IEDP\XMLsamples