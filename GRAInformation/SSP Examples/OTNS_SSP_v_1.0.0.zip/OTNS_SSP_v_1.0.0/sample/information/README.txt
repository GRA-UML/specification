sample XML instances see the samplesincluded in the IEPD
package at artifacts\service model\information model